import 'dart:ui';
import 'package:flutter/material.dart';
import 'Darts/SplashPage.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: colorCustom,
      ),
      //Set Home Page after splash
      home: SplashPage(),
    );
  }
}
MaterialColor colorCustom = MaterialColor(0xff4e4c4d, color); //appBarColor
Map<int, Color> color = {
  50: Color.fromRGBO(78, 76, 77, .1),
  100: Color.fromRGBO(78, 76, 77, .2),
  200: Color.fromRGBO(78, 76, 77, .3),
  300: Color.fromRGBO(78, 76, 77, .4),
  400: Color.fromRGBO(78, 76, 77, .5),
  500: Color.fromRGBO(78, 76, 77, .6),
  600: Color.fromRGBO(78, 76, 77, .7),
  700: Color.fromRGBO(78, 76, 77, .8),
  800: Color.fromRGBO(78, 76, 77, .9),
  900: Color.fromRGBO(78, 76, 77, 1),
};
