
class JifyFont {
  static const double font_f1 = 14.5; //font normal
  static const double font_f3 = 16.5;
  static const double font_f4 = 19.5;
}

