import 'dart:ui';

import 'package:flutter/material.dart';

class ColorConstants {
  static const Color appBarColor=Color(0xff4e4c4d);
  static const Color pageBackground_light=Color(0xfff5f5f5);//0xfff4f2f2
  static const Color colorWhite=Color(0xffffffff);
  static const Color primaryTextColor=Color(0xff383838);
  static const Color secondaryTextColor=Color(0xff686868);
  static const Color bottomNavDimColor=Color(0xff666666);
  static const Color dimTextColor=Color(0xffb3b3b3);
  static const Color colorTransparent=Color(0xff737373);
}
