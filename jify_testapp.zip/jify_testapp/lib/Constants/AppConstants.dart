class AppConstants {
  static const String BASE_ADDRESS = "https://pixabay.com/api/";
  static const String LICENSE_KEY = "?key=24104660-0b6529fec2948fca493aba956";
  static const String FETCH_PHOTOS = "&q=yellow+flowers&image_type=photo";

  static const String HOME_PAGE_TITLE = "Jify Sample App";

}