import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:jify_test_app/Constants/ColorConstants.dart';
import 'package:jify_test_app/Darts/HomePage.dart';
import 'package:transparent_image/transparent_image.dart';

class DetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        child: Center(
          child: Hero(
            tag: 'imageLarge',
            child: FadeInImage.memoryNetwork(
              image: largeImage,
              placeholder: kTransparentImage,
              imageErrorBuilder: (context, ob, stack) => Container(
                  alignment: Alignment.center,
                  child: IconButton(
                      icon: Icon(
                        Icons.replay,
                        color: ColorConstants.colorWhite,
                      ))),
              fit: BoxFit.cover,
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height,
            ),
          ),
        ),
        onTap: () {
          Navigator.pop(context);
        },
      ),
    );
  }
}