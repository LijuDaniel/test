//SplashPage
import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:flutter/services.dart';
import 'package:jify_test_app/Constants/AppConstants.dart';
import 'package:jify_test_app/Constants/ColorConstants.dart';
import 'package:jify_test_app/Constants/JifyFonts.dart';

import 'HomePage.dart';

class SplashPage extends StatefulWidget {
  SplashPage({Key key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  bool _visible = false;

  @override
  void initState() {
    super.initState();

    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    Timer(Duration(milliseconds: 100), () {
      setState(() {
        // _controller.play();
        _visible = true;
      });
    });
    Future.delayed(Duration(seconds: 4), () {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (context) => HomePage()), (e) => false);
    });
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container( color: ColorConstants.colorWhite,
          child: Center(
        child: Text(
          AppConstants.HOME_PAGE_TITLE,
          style: TextStyle(
              color: ColorConstants.appBarColor,
              fontSize: JifyFont.font_f4,
              fontWeight: FontWeight.bold),
        ),
      )),
    );
  }
}
