import 'dart:convert';
import 'dart:io';
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:jify_test_app/Constants/AppConstants.dart';
import 'package:jify_test_app/Constants/ColorConstants.dart';
import 'package:jify_test_app/Constants/JifyFonts.dart';
import 'package:jify_test_app/Methods/AppFunctions.dart';
import 'package:jify_test_app/Pojo/Pojos.dart';
import 'package:http/http.dart' as http;
import 'package:transparent_image/transparent_image.dart';

import 'DetailPage.dart';

String largeImage = "";

class HomePage extends StatefulWidget {
  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> {
  List<PhotoList> photoListSource = [];
  List<PhotoList> photoList = [];
  Future<PhotoBase> _future;
  TextEditingController searchcontroller = new TextEditingController();
  Icon actionIcon = new Icon(
    Icons.search,
    color: Colors.white,
  );

  @override
  void initState() {
    super.initState();
    _future = _fetchPhoto();
  }

  void changeImage(String img) {
    setState(() {
      largeImage = img;
    });
  }

  @override
  Widget build(BuildContext context) {
    //final vm = Provider.of<FundlistViewModel>(context);
    return new Scaffold(
      appBar: AppBar(
        title: Text(AppConstants.HOME_PAGE_TITLE),
      ),
      body: photoBody(),
    );
  }

  Widget photoBody() {
    return FutureBuilder<PhotoBase>(
      //future: fetchProducts(), // api call method here, to fetch json/data
      future: _future, // api call method here, to fetch json/data
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Container(); // widget to be shown on any error
        }

        return
            // snapshot.hasData? _page1bodyBuild(data_: snapshot.data.hits)
            snapshot.hasData
                ? bodyBuild(data_: snapshot.data.hits)
                : Center(
                    child: Image.asset(
                      "assets/ic_loader.gif",
                      height: 80.0,
                      width: 80.0,
                    ),
                  );
      },
    );
  }

  var outerBorder = Border.all(width: 1.0, color: Colors.grey);

  Widget bodyBuild({List<PhotoList> data_}) {
    return new Column(children: <Widget>[
      Padding(
        padding: const EdgeInsets.fromLTRB(8, 14, 8, 8),
        child: Container(
            height: 54,
            child: TextField(
              onChanged: onSearchTextChanged,
              controller: searchcontroller,
              decoration: InputDecoration(
                  focusedBorder: const OutlineInputBorder(
                      borderSide: const BorderSide(
                          color: ColorConstants.secondaryTextColor, width: 0.9),
                      borderRadius: BorderRadius.all(Radius.circular(5.0))),
                  labelText: "Search",
                  hintText: "Search",
                  hintStyle: TextStyle(
                    color: ColorConstants.secondaryTextColor,
                  ),
                  prefixIcon: Icon(
                    Icons.search,
                    color: ColorConstants.secondaryTextColor,
                  ),
                  border: OutlineInputBorder(
                      borderSide: const BorderSide(
                          color: ColorConstants.secondaryTextColor, width: 0.5),
                      borderRadius: BorderRadius.all(Radius.circular(8.0)))),
            )),
      ),
      new Expanded(
        child: Container(
            margin: EdgeInsets.all(0),
            color: ColorConstants.pageBackground_light,
            child: ListView.builder(
              physics: BouncingScrollPhysics(),
              itemCount: photoList.length,
              itemBuilder: (context, index) {
                final item = photoList[index];
                return GestureDetector(
                  child: Container(
                    height: 140,
                    margin: EdgeInsets.fromLTRB(8, 0, 8, 14),
                    decoration: BoxDecoration(
                        color: ColorConstants.colorWhite,
                        borderRadius: BorderRadius.circular(10)),
                    child: Row(
                      children: [
                        Expanded(
                          flex: 1,
                          child: Container(
                              height: 140,
                              child: ClipRRect(
                                  borderRadius: BorderRadius.circular(10.0),
                                  child: FadeInImage.memoryNetwork(
                                    image: item.previewURL,
                                    placeholder: kTransparentImage,
                                    imageErrorBuilder: (context, ob, stack) =>
                                        Container(
                                            alignment: Alignment.center,
                                            child: IconButton(
                                                icon: Icon(
                                              Icons.replay,
                                              color: ColorConstants.colorWhite,
                                            ))),
                                    fit: BoxFit.cover,
                                    width: MediaQuery.of(context).size.width,
                                    height: MediaQuery.of(context).size.height,
                                  ))),
                        ),
                        Expanded(
                          flex: 2,
                          child: Container(
                              margin: EdgeInsets.fromLTRB(5, 0, 0, 0),
                              padding: EdgeInsets.fromLTRB(5, 5, 5, 5),
                              alignment: Alignment.center,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    child: Row(
                                      children: <Widget>[
                                        Expanded(
                                          flex: 3,
                                          child: Container(
                                            alignment: Alignment.center,
                                            child: new Container(
                                              alignment: Alignment.centerLeft,
                                              child: new Text(
                                                'User: ' + item.user,
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                                textAlign: TextAlign.start,
                                                style: TextStyle(
                                                  color: ColorConstants
                                                      .primaryTextColor,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 15,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                            flex: 1,
                                            child: Container(
                                              alignment: Alignment.centerRight,
                                              child: new InkWell(
                                                focusColor: Colors.black26,
                                                child: new Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.end,
                                                  children: <Widget>[
                                                    new Text(
                                                      'Type',
                                                      style: TextStyle(
                                                          color: ColorConstants
                                                              .primaryTextColor,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 9),
                                                    ),
                                                    new Text(
                                                      '',
                                                      style: TextStyle(
                                                          fontSize: 2),
                                                    ),
                                                    new Text(
                                                      item.type,
                                                      style: TextStyle(
                                                          color: ColorConstants
                                                              .primaryTextColor,
                                                          fontWeight:
                                                              FontWeight.bold,
                                                          fontSize: 12),
                                                    ),
                                                  ],
                                                ),
                                                onTap: () {
                                                  // TODO(implement)
                                                },
                                              ),
                                            )),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    width: MediaQuery.of(context).size.width,
                                    alignment: Alignment.centerLeft,
                                    margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                                    child: RichText(
                                      text: TextSpan(
                                        children: <TextSpan>[
                                          TextSpan(
                                              text: 'Likes: ' +
                                                  item.likes.toString() +
                                                  "\n\n",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: JifyFont.font_f1,
                                                  color: ColorConstants
                                                      .primaryTextColor)),
                                          TextSpan(
                                              text: 'Tags: ' + item.tags,
                                              style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: JifyFont.font_f1,
                                                  color: ColorConstants
                                                      .primaryTextColor)),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              )),
                        )
                      ],
                    ),
                  ),
                  onTap: () {
                    changeImage(item.largeImageURL);
                    Navigator.push(context, MaterialPageRoute(builder: (_) {
                      return DetailPage();
                    }));
                  },
                );
              },
            )),
      ),
    ]);
  }

  Future<PhotoBase> _fetchPhoto() async {
    try {
      final response = await http.post(Uri.parse(AppConstants.BASE_ADDRESS +
          AppConstants.LICENSE_KEY +
          AppConstants.FETCH_PHOTOS));
      if (response.statusCode == 200) {
        Printing.printText(response.body);
        Printing.printText('Response_Photos');
        PhotoBase _photoBase = PhotoBase.fromJson(jsonDecode(response.body));
        photoListSource.addAll(_photoBase.hits);
        photoList.addAll(_photoBase.hits);
        return _photoBase;
      } else {
        throw Exception('Unable to fetch products from the REST API');
      }
    } on SocketException catch (_) {
      Toasting.showToast('Please check your internet connection');
    }
  }

  onSearchTextChanged(String text) async {
    List<PhotoList> searchResult = [];
    if (text.isEmpty) {
      setState(() {
        photoList = photoListSource;
      });
      return;
    }
    searchResult = photoListSource
        .where((i) =>
            i.user.toLowerCase().contains(text.toLowerCase().trim()) ||
            i.tags.toLowerCase().contains(text.toLowerCase().trim()))
        .toList();
    setState(() {
      photoList = searchResult;
    });
  }
}
