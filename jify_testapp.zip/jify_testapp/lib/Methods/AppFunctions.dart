import 'package:fluttertoast/fluttertoast.dart';
import 'package:jify_test_app/Constants/ColorConstants.dart';
import 'package:jify_test_app/Constants/JifyFonts.dart';

class Toasting {
  static void showToast(String s) {
    Fluttertoast.showToast(
        msg: s,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: ColorConstants.colorWhite,
        textColor: ColorConstants.primaryTextColor,
        fontSize: JifyFont.font_f3);
  }
}

class Printing {
  static void printText(String p) {
    print(p);
  }
}
